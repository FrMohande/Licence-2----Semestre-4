package battleship;

/**
 * @author : Mohand Outioua
 */

public enum Answer {
	MISSED, HIT, SUNK;
}