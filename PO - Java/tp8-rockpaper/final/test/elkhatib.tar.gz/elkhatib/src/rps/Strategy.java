package rps;

public interface Strategy {
	/* this function allow of a player to choose which strategy he will play */ 
	public Shape chooseShape() ;
}
