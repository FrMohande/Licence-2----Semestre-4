TP effectué par Eddy El Khatib et Mohand outioua

toutes les manips sont automatisées avec un makefile contenant les fonctions que vous citez dans vos consignes (tst, compile, jar, etc...)

Pour effectuer la totalité des manips en un seul coup : make

bonne correction
