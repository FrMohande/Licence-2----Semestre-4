

extern void * monmalloc(unsigned int) ;
extern void free(void *ptr);
