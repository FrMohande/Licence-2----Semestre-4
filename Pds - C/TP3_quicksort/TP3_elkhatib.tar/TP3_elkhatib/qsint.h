#ifndef QSINT_H
#define QSINT_H

extern void quicksort(int *tab, unsigned int nelem);

#endif