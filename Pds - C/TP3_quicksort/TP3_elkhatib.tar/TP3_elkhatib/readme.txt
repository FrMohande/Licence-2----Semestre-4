TP EFFECTUE PAR EDDY EL KHATIB

Pour effectuer mes tests :

test (pour qs generique avec les diff�rentes fonctions de comparaison et msort)

testI pour l'intermezzo

qsint_tst pour le test du quicksort d'entier

les fichiers pour les tests sont les suivants :
	testINTERMEZZO.c
	testQS.c
	testQSINT.c
	liste.txt(pour le msort)
	
msutil est le fichier contenant les fonctions pour msort


exercice non r�ussi : msort, il m'est impossible de r�cup�rer les donn�es du fichier liste.txt et l'afficher tri� en suite, c'est comme si mon quicksort generique avec comparaison de chaines ne fonctionnait pas alors qu'il marche bien dans mes tests.

Bonne correction