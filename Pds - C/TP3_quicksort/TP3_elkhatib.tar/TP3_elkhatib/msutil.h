#ifndef MSUTIL_H
#define MSUTIL_H

extern int fill(int** texte);
extern void afficher(int** texte, int size); 

#endif
