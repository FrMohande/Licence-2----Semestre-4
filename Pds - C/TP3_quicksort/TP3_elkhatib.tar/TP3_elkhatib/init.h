#ifndef INIT_H
#define INIT_H


extern void randTab(int tab[]);
extern void afficher_tableau(int tab[], int size);


#endif
