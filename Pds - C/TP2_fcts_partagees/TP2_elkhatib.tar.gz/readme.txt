TP effectué par Eddy El Khatib

tous les fichiers présents sont utiles et leur fonctionnement est expliqué lors de l'execution de "make test".

Bonne correction
