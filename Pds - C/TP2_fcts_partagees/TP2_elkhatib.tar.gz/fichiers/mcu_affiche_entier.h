

#ifndef MCU_AFFICHE_ENTIER_H
#define MCU_AFFICHE_ENTIER_H



extern void affiche_entier(int) ;
/* retourne sur la sortie standard gr\^ace \`a putchar (cf. man) la
   cha\^\i{}ne de caract\`eres repr\'esentant l'entier pris en 
   param\`etre. */


#endif
