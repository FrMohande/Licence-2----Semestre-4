#ifndef MCU_MACROS_H
#define MCU_MACROS_H

#define MAXLINE  81
#define LINETOOLONG 2

#endif