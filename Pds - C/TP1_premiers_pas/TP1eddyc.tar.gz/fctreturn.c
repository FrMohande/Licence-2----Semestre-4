#include <stdio.h>

int main (void) {
  /*exercice 13 */
  /*return 7; */ 
  return 256;
  
  	/*exercice 14 : */ 
	/*putchar(getchar());*/

}
