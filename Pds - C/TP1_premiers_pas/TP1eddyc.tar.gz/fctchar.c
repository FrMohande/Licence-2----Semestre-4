#include <stdio.h>

int main (void) {

  putchar(getchar());

}
