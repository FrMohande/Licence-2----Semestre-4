tp effectué par Eddy El Khatib

(** Question 4 : Pour une taille de 2^2 on a un faux positif sur un mot tiré aléatoirement *)

remarque: l'execution de testtp4 ne fait pas de boucle infinie, il met juste pas mal de temps avant d'afficher son résultat
