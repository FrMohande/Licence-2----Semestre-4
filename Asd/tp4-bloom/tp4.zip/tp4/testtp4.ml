open Bloomfilter

let nb_hash_functions = 8

let random_tab = Array.make (128 * nb_hash_functions) 0

let init_random_tab () =
  Random.self_init ();
  for i = 0 to 127 do
    for j = 0 to nb_hash_functions - 1 do
      random_tab.(j*128+i) <- (Random.int 32000)
    done;
  done

let code_of_string str n =
  0
  
let random_word () =
  let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
  and length = 4 + Random.int (4)
  in
  let str = String.create length
  in
  for i = 0 to length - 1 do
    str.[i] <- letters.[(Random.int 51)]
  done;
  str
   
let _ = 
  init_random_tab ();
  (* creation du filtre *)
  let bf = new_bloomfilter 2 code_of_string 8
  and s = random_word ()
  in
  add bf "timoleon";
  Printf.printf "timoleon est present : %b\n" (contains bf "timoleon");
  Printf.printf "%s est present : %b\n" s (contains bf s)

    


  
