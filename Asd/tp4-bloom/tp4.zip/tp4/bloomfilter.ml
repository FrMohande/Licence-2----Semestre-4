type 'a bloomfilter = { filter : bool array ; code : 'a -> int -> int ; nb : int}

let new_bloomfilter n f m =

let add bf e =
  (* calculer la valeur de chaque fonction de hachage pour l'element [e]
     et mettre a vrai la case correspondante *)

let contains bf e =
  (* calculer la valeur de chaque fonction de hachage pour l'element [e]
     et tester si toutes les cases sont a vrai *)
