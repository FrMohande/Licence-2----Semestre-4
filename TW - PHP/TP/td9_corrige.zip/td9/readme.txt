Il y a un fichier Note.txt dans le r�pertoire php/
N'oubliez pas d'inclure votre login dans le fichier php/DB_connect.php

Ceci n'est pas l'unique correction possible du td9 de TW2, mais une parmis toutes.