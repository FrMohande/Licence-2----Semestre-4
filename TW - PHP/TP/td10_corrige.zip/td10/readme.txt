Propos� par Matthieu Lepers
Il manque les questions 1.7 et 1.8

Votre base de donn�e doit comport� les tables:
- personne
- interets